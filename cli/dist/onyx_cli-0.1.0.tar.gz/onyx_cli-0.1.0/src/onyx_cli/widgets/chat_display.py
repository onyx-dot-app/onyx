"""Scrollable chat display widget with rich markdown rendering."""

from __future__ import annotations

from rich.markdown import Markdown
from rich.text import Text

from textual.widgets import RichLog


class ChatDisplay(RichLog):
    """Scrollable message area with rich markdown rendering.

    User messages are shown with a bold prefix.
    Assistant messages are rendered as markdown, streamed token-by-token.
    Search/reasoning indicators are shown in dimmed text.
    """

    DEFAULT_CSS = """
    ChatDisplay {
        width: 100%;
        height: 1fr;
        padding: 0 1;
        scrollbar-size: 1 1;
    }
    """

    def __init__(self) -> None:
        super().__init__(wrap=True, highlight=True, markup=True, auto_scroll=True)
        self._current_assistant_text: str = ""
        self._is_streaming: bool = False
        self._reasoning_text: str = ""
        self._is_reasoning: bool = False

    def add_user_message(self, message: str) -> None:
        """Add a user message to the display."""
        self.write("")
        self.write(Text.from_markup("[bold cyan]You[/bold cyan]"))
        self.write(Text(message))

    def start_assistant_message(self) -> None:
        """Start a new assistant response section."""
        self._current_assistant_text = ""
        self._is_streaming = True
        self.write("")
        self.write(Text.from_markup("[bold green]Onyx[/bold green]"))

    def append_token(self, token: str) -> None:
        """Append a token to the current assistant response."""
        self._current_assistant_text += token
        # Re-render the full markdown on each token for proper formatting
        self._render_current_response()

    def _render_current_response(self) -> None:
        """Re-render the current assistant response as markdown."""
        if not self._current_assistant_text:
            return

        # Remove the last line (previous render) and replace it
        # For streaming, we use a simple approach: clear last written content
        # and rewrite. RichLog doesn't support in-place updates natively,
        # so we write the text and it appends. For the streaming effect,
        # we use clear + rewrite on the final render.
        # During streaming, just write raw text for performance.
        if self._is_streaming:
            self.clear()
            # Re-add the "Onyx" header
            self.write(Text.from_markup("[bold green]Onyx[/bold green]"))
            self.write(Markdown(self._current_assistant_text))

    def finish_assistant_message(self) -> None:
        """Finalize the assistant message, render full markdown."""
        self._is_streaming = False
        if self._current_assistant_text:
            self.clear()
            self.write(Text.from_markup("[bold green]Onyx[/bold green]"))
            self.write(Markdown(self._current_assistant_text))

    def start_reasoning(self) -> None:
        """Start a reasoning block."""
        self._is_reasoning = True
        self._reasoning_text = ""
        self.write(Text.from_markup("\n[dim italic]Thinking...[/dim italic]"))

    def append_reasoning(self, text: str) -> None:
        """Append text to the reasoning block."""
        self._reasoning_text += text

    def finish_reasoning(self) -> None:
        """Close the reasoning block."""
        self._is_reasoning = False
        if self._reasoning_text:
            self.write(Text.from_markup(f"[dim]{self._reasoning_text}[/dim]"))

    def show_search_indicator(self, queries: list[str] | None = None, is_internet: bool = False) -> None:
        """Show a search indicator."""
        prefix = "Web search" if is_internet else "Searching"
        if queries:
            query_text = ", ".join(f'"{q}"' for q in queries[:3])
            self.write(Text.from_markup(f"[dim]{prefix}: {query_text}[/dim]"))
        else:
            self.write(Text.from_markup(f"[dim]{prefix}...[/dim]"))

    def show_documents_found(self, count: int) -> None:
        """Show how many documents were found."""
        self.write(Text.from_markup(f"[dim]Found {count} document{'s' if count != 1 else ''}[/dim]"))

    def show_citations(self, citations: dict[int, str]) -> None:
        """Show citation references at the end of a response."""
        if not citations:
            return
        self.write("")
        self.write(Text.from_markup("[bold]Sources[/bold]"))
        for num, doc_id in sorted(citations.items()):
            self.write(Text.from_markup(f"  [dim][{num}][/dim] {doc_id}"))

    def show_tool_start(self, tool_name: str) -> None:
        """Show that a tool is being used."""
        self.write(Text.from_markup(f"[dim]Using {tool_name}...[/dim]"))

    def show_error(self, error: str) -> None:
        """Show an error message."""
        self.write("")
        self.write(Text.from_markup(f"[bold red]Error:[/bold red] {error}"))

    def show_info(self, message: str) -> None:
        """Show an informational message."""
        self.write(Text.from_markup(f"[dim]{message}[/dim]"))

    def show_research_task(self, task: str) -> None:
        """Show a deep research sub-task."""
        self.write(Text.from_markup(f"[dim]Researching: {task}[/dim]"))
