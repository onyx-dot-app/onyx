"""First-run onboarding flow for Onyx CLI."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Vertical, Center
from textual.screen import Screen
from textual.widgets import Input, Static, Button

from onyx_cli.config import OnyxCliConfig, save_config
from onyx_cli.widgets.splash import SplashWidget


WELCOME_TEXT = """\
Welcome to [bold]Onyx CLI[/bold] - your terminal interface for Onyx.

Let's get you connected to your Onyx server.
"""

COMMANDS_OVERVIEW = """\
[bold]Quick Start[/bold]

  Just type to chat with your Onyx assistant.

  [dim]/help[/dim]        Show all commands
  [dim]/attach[/dim]      Attach a file
  [dim]/persona[/dim]     Switch assistant
  [dim]/new[/dim]         Start new conversation
  [dim]/configure[/dim]   Change connection settings
  [dim]/sessions[/dim]    Browse previous chats
  [dim]Escape[/dim]       Cancel current generation
  [dim]Ctrl+D[/dim]       Quit
"""


class OnboardingScreen(Screen[OnyxCliConfig | None]):
    """First-run onboarding screen with setup prompts."""

    DEFAULT_CSS = """
    OnboardingScreen {
        align: center middle;
        background: $surface;
    }

    OnboardingScreen #container {
        width: 70;
        height: auto;
        padding: 1 2;
    }

    OnboardingScreen .welcome {
        text-align: center;
        padding: 0 0 1 0;
    }

    OnboardingScreen .label {
        padding: 1 0 0 0;
        color: #A0A0A0;
    }

    OnboardingScreen Input {
        width: 100%;
    }

    OnboardingScreen .status {
        padding: 1 0;
        text-align: center;
        min-height: 1;
    }

    OnboardingScreen .commands-overview {
        padding: 1 0;
    }

    OnboardingScreen .button-row {
        width: 100%;
        height: auto;
        align: center middle;
        padding: 1 0;
    }

    OnboardingScreen Button {
        min-width: 20;
    }
    """

    BINDINGS = [
        ("escape", "cancel", "Cancel"),
    ]

    def __init__(self, existing_config: OnyxCliConfig | None = None) -> None:
        super().__init__()
        self._config = existing_config or OnyxCliConfig()

    def compose(self) -> ComposeResult:
        with Vertical(id="container"):
            with Center():
                yield SplashWidget()
            yield Static(WELCOME_TEXT, classes="welcome", markup=True)

            yield Static("Onyx Server URL", classes="label")
            yield Input(
                value=self._config.server_url,
                placeholder="http://localhost:3000",
                id="server_url",
            )

            yield Static("API Key or Personal Access Token", classes="label")
            yield Input(
                value=self._config.api_key,
                placeholder="paste your API key here",
                password=True,
                id="api_key",
            )

            yield Static("", id="status", classes="status")
            yield Static(COMMANDS_OVERVIEW, classes="commands-overview", markup=True)

            with Center(classes="button-row"):
                yield Button("Connect", variant="primary", id="connect")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "connect":
            await self._attempt_connect()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        # Enter on any input field triggers connect
        await self._attempt_connect()

    async def _attempt_connect(self) -> None:
        server_url = self.query_one("#server_url", Input).value.strip()
        api_key = self.query_one("#api_key", Input).value.strip()
        status = self.query_one("#status", Static)

        if not server_url:
            status.update("[bold red]Please enter a server URL[/bold red]")
            return

        config = OnyxCliConfig(
            server_url=server_url,
            api_key=api_key,
            default_persona_id=self._config.default_persona_id,
        )

        status.update("[yellow]Testing connection...[/yellow]")

        from onyx_cli.api_client import OnyxApiClient

        client = OnyxApiClient(config)
        try:
            success = await client.test_connection()
            if success:
                save_config(config)
                status.update("[bold green]Connected! Starting Onyx CLI...[/bold green]")
                self.dismiss(config)
            else:
                status.update(
                    "[bold red]Connection failed.[/bold red] Check your server URL and API key.\n"
                    "[dim]Make sure the server is running and your credentials are valid.[/dim]"
                )
        except Exception as e:
            status.update(f"[bold red]Error:[/bold red] {e}")
        finally:
            await client.close()

    def action_cancel(self) -> None:
        self.dismiss(None)
