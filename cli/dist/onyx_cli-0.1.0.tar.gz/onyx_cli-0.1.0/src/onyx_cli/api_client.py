"""Async HTTP client for the Onyx API."""

from __future__ import annotations

import mimetypes
from collections.abc import AsyncIterator
from pathlib import Path
from uuid import UUID

import httpx

from onyx_cli.config import OnyxCliConfig
from onyx_cli.models import (
    CategorizedFilesSnapshot,
    ChatSessionCreationInfo,
    ChatSessionDetailResponse,
    ChatSessionDetails,
    ChatFileType,
    FileDescriptorPayload,
    PersonaSummary,
    SendMessagePayload,
    StreamEvent,
)
from onyx_cli.stream_parser import parse_stream_line


class OnyxApiError(Exception):
    """Raised when an Onyx API call fails."""

    def __init__(self, status_code: int, detail: str) -> None:
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class OnyxApiClient:
    """Async client for communicating with the Onyx server."""

    def __init__(self, config: OnyxCliConfig) -> None:
        self._config = config
        self._base_url = config.server_url.rstrip("/")
        self._client: httpx.AsyncClient | None = None

    @property
    def client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            headers: dict[str, str] = {}
            if self._config.api_key:
                headers["Authorization"] = f"Bearer {self._config.api_key}"
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                headers=headers,
                timeout=httpx.Timeout(30.0, read=120.0),
            )
        return self._client

    async def close(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()

    def update_config(self, config: OnyxCliConfig) -> None:
        """Update the client config. Closes existing connection."""
        self._config = config
        self._base_url = config.server_url.rstrip("/")
        if self._client and not self._client.is_closed:
            # Will be lazily recreated on next request
            import asyncio

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(self._client.aclose())
            except RuntimeError:
                pass
            self._client = None

    # ── Health / Connection Test ─────────────────────────────────────

    async def test_connection(self) -> bool:
        """Test if the server is reachable and credentials are valid."""
        try:
            resp = await self.client.get("/api/chat/get-user-chat-sessions")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    # ── Personas ─────────────────────────────────────────────────────

    async def list_personas(self) -> list[PersonaSummary]:
        """Get available personas/assistants."""
        resp = await self.client.get("/api/persona")
        resp.raise_for_status()
        raw_list = resp.json()
        return [
            PersonaSummary(
                id=p["id"],
                name=p["name"],
                description=p.get("description", ""),
                is_default_persona=p.get("is_default_persona", False),
            )
            for p in raw_list
            if p.get("is_visible", True)
        ]

    # ── Chat Sessions ────────────────────────────────────────────────

    async def list_chat_sessions(self) -> list[ChatSessionDetails]:
        """Get recent chat sessions."""
        resp = await self.client.get("/api/chat/get-user-chat-sessions")
        resp.raise_for_status()
        data = resp.json()
        sessions = data.get("sessions", [])
        return [
            ChatSessionDetails(
                id=s["id"],
                name=s.get("name"),
                persona_id=s.get("persona_id"),
                time_created=s.get("time_created", ""),
                time_updated=s.get("time_updated", ""),
            )
            for s in sessions
        ]

    async def get_chat_session(self, session_id: UUID) -> ChatSessionDetailResponse:
        """Get full details for a chat session including messages."""
        resp = await self.client.get(f"/api/chat/get-chat-session/{session_id}")
        resp.raise_for_status()
        data = resp.json()
        return ChatSessionDetailResponse(**data)

    # ── File Upload ──────────────────────────────────────────────────

    async def upload_file(self, file_path: Path) -> FileDescriptorPayload:
        """Upload a file and return a file descriptor for use in messages."""
        mime_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"

        with open(file_path, "rb") as f:
            files = {"files": (file_path.name, f, mime_type)}
            resp = await self.client.post(
                "/api/user/projects/file/upload",
                files=files,
                timeout=httpx.Timeout(60.0),
            )

        resp.raise_for_status()
        snapshot = CategorizedFilesSnapshot(**resp.json())

        if not snapshot.user_files:
            raise OnyxApiError(400, "File upload returned no files")

        uf = snapshot.user_files[0]
        return FileDescriptorPayload(
            id=uf.file_id,
            type=uf.chat_file_type,
            name=file_path.name,
        )

    # ── Send Message (Streaming) ─────────────────────────────────────

    async def send_message_stream(
        self,
        message: str,
        chat_session_id: UUID | None = None,
        persona_id: int = 0,
        parent_message_id: int | None = -1,
        file_descriptors: list[FileDescriptorPayload] | None = None,
    ) -> AsyncIterator[StreamEvent]:
        """Send a chat message and yield streaming events."""
        payload = SendMessagePayload(
            message=message,
            parent_message_id=parent_message_id,
            file_descriptors=[
                {"id": fd.id, "type": fd.type.value, "name": fd.name}
                for fd in (file_descriptors or [])
            ],
        )

        if chat_session_id is not None:
            payload.chat_session_id = str(chat_session_id)
        else:
            payload.chat_session_info = ChatSessionCreationInfo(persona_id=persona_id)

        async with self.client.stream(
            "POST",
            "/api/chat/send-chat-message",
            json=payload.model_dump(exclude_none=True),
            timeout=httpx.Timeout(30.0, read=300.0),
        ) as response:
            if response.status_code != 200:
                body = await response.aread()
                raise OnyxApiError(response.status_code, body.decode(errors="replace"))

            async for line in response.aiter_lines():
                event = parse_stream_line(line)
                if event is not None:
                    yield event

    # ── Stop Chat Session ────────────────────────────────────────────

    async def stop_chat_session(self, session_id: UUID) -> None:
        """Send stop signal for a streaming chat session."""
        try:
            resp = await self.client.post(f"/api/chat/stop-chat-session/{session_id}")
            resp.raise_for_status()
        except httpx.HTTPError:
            pass  # Best-effort
